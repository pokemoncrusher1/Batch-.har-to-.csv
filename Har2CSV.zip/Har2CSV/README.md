Dependencies: Node JS installed-NPM
 
First time Use: Install.bat to install - you need Nodejs, run as admin if error
 
place .har into Input folder
then run.bat  
- CSV out of Output folder

main conversion- credit goes to
https://github.com/google/har2csv
